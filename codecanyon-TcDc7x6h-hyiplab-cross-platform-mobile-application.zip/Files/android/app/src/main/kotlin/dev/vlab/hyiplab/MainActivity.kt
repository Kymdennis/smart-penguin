package dev.vlab.hyiplab

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
