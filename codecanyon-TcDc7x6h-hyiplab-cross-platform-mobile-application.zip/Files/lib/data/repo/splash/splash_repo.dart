
import 'package:hyip_lab/data/services/api_service.dart';


class SplashRepo{
  ApiClient apiClient;
  SplashRepo({required this.apiClient});
}